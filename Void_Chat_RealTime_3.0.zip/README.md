# Void Chat 3.0

灰色 / 白色 / 淡蓝色主题的实时多人聊天网站。

## 功能
- 注册 / 登录
- Socket.IO 实时聊天
- General / Gaming / Support / News 多频道
- 在线成员
- SQLite 永久保存消息
- 手机与 Chromebook 自适应
- 基础禁言数据库接口

## 本地运行

需要 Node.js 18+。

```bash
npm install
npm start
```

然后打开：

http://localhost:3000

## 部署

把整个项目部署到支持 Node.js 的服务器/云平台，并使用：

```bash
npm start
```

启动。

数据库文件 `void-chat.db` 会在服务器运行后自动创建。

## 注意

这是 3.0 基础完整版本。生产环境还应加入 HTTPS、密码更安全的哈希算法、账号限流、CSRF/安全策略、管理员认证和更完整的数据库备份。
