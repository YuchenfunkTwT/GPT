# Void Chat 3.0 — Real-time deployment

## Local
Node.js 18+:
```bash
npm install
npm start
```
Open http://localhost:3000

## Backend deployment
Deploy this repository to a Node.js hosting service.
Build command:
`npm install`

Start command:
`npm start`

Set `PORT` if your host requires it.

The server exposes:
`GET /api/health`

For a separate GitHub Pages frontend, set:
`FRONTEND_ORIGIN=https://YOUR-USERNAME.github.io`

For the easiest setup, however, deploy the included `public` folder from the same Node server. It serves the frontend and backend from one URL, avoiding CORS configuration.

## Database
SQLite is stored in `void-chat.db`. For production, use persistent disk/storage on the host so the database survives restarts/redeploys.

## Features
- Real-time Socket.IO messaging
- Multiple rooms
- Account registration/login
- Online member list
- Persistent SQLite messages
- Mobile/Chromebook-friendly UI
