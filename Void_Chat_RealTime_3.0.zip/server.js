import express from "express";
import http from "http";
import { Server } from "socket.io";
import Database from "better-sqlite3";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const server = http.createServer(app);

const allowedOrigin = process.env.FRONTEND_ORIGIN || true;
const io = new Server(server, {
  cors: { origin: allowedOrigin, methods: ["GET", "POST"] }
});

const db = new Database(process.env.DB_FILE || "void-chat.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password TEXT NOT NULL,
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS messages(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 room TEXT NOT NULL,
 user_id INTEGER NOT NULL,
 username TEXT NOT NULL,
 text TEXT NOT NULL,
 created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_room_id ON messages(room,id);
`);

const rooms = ["general","gaming","support","news"];
const sessions = new Map();
const online = new Map();

app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname,"public")));
app.get("/api/health",(_req,res)=>res.json({ok:true,service:"Void Chat 3.0",time:new Date().toISOString()}));

const hash = s => crypto.createHash("sha256").update(s).digest("hex");
const newToken = () => crypto.randomBytes(32).toString("hex");

app.post("/api/register",(req,res)=>{
  const username=String(req.body.username||"").trim().slice(0,24);
  const password=String(req.body.password||"");
  if(!/^[A-Za-z0-9_ -]{2,24}$/.test(username)) return res.status(400).json({error:"昵称需为2-24个字母、数字、空格、下划线或短横线。"});
  if(password.length<4) return res.status(400).json({error:"密码至少4个字符。"});
  if(db.prepare("SELECT id FROM users WHERE username=?").get(username)) return res.status(409).json({error:"昵称已存在。"});
  const r=db.prepare("INSERT INTO users(username,password,created_at) VALUES(?,?,?)").run(username,hash(password),new Date().toISOString());
  const user={id:Number(r.lastInsertRowid),username}, token=newToken();
  sessions.set(token,user); res.json({token,username});
});

app.post("/api/login",(req,res)=>{
  const username=String(req.body.username||"").trim(), password=String(req.body.password||"");
  const user=db.prepare("SELECT id,username FROM users WHERE username=? AND password=?").get(username,hash(password));
  if(!user) return res.status(401).json({error:"账号或密码错误。"});
  const token=newToken(); sessions.set(token,user); res.json({token,username:user.username});
});

function auth(token){return sessions.get(String(token||""))||null}
function broadcastOnline(room){
  io.to(room).emit("online",[...online.values()].filter(x=>x.room===room).map(x=>({username:x.username})));
}
function history(socket,room){
  const rows=db.prepare("SELECT username,text,created_at AS time FROM messages WHERE room=? ORDER BY id DESC LIMIT 100").all(room).reverse();
  socket.emit("history",rows);
}

io.on("connection",socket=>{
  socket.on("auth",token=>{
    const user=auth(token);
    if(!user)return socket.emit("authError","登录已失效，请重新登录。");
    online.set(socket.id,{...user,room:"general"});
    socket.join("general");
    socket.emit("ready",{username:user.username,rooms});
    history(socket,"general"); broadcastOnline("general");
  });

  socket.on("room",room=>{
    const u=online.get(socket.id);
    if(!u||!rooms.includes(room))return;
    const old=u.room;
    if(old===room)return history(socket,room);
    socket.leave(old); broadcastOnline(old);
    u.room=room; socket.join(room); history(socket,room); broadcastOnline(room);
  });

  socket.on("message",raw=>{
    const u=online.get(socket.id);
    if(!u)return;
    const text=String(raw||"").trim().slice(0,1000);
    if(!text)return;
    const now=new Date().toISOString();
    const r=db.prepare("INSERT INTO messages(room,user_id,username,text,created_at) VALUES(?,?,?,?,?)")
      .run(u.room,u.id,u.username,text,now);
    io.to(u.room).emit("message",{id:Number(r.lastInsertRowid),username:u.username,text,time:now});
  });

  socket.on("disconnect",()=>{
    const u=online.get(socket.id); online.delete(socket.id);
    if(u)broadcastOnline(u.room);
  });
});

const PORT=Number(process.env.PORT||3000);
server.listen(PORT,()=>console.log(`Void Chat realtime server listening on ${PORT}`));
