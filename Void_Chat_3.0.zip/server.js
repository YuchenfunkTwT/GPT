import express from "express";
import http from "http";
import { Server } from "socket.io";
import Database from "better-sqlite3";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new Database("void-chat.db");

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  username TEXT NOT NULL,
  text TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS bans (
  username TEXT PRIMARY KEY,
  reason TEXT
);
`);

const rooms = ["general", "gaming", "support", "news"];
const sessions = new Map();
const online = new Map();

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "public")));

const hash = value =>
  crypto.createHash("sha256").update(value).digest("hex");

function validRoom(room) {
  return rooms.includes(room) ? room : "general";
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, name: "Void Chat 3.0" });
});

app.post("/api/register", (req, res) => {
  const username = String(req.body.username || "").trim().slice(0, 24);
  const password = String(req.body.password || "");

  if (!/^[A-Za-z0-9_ -]{2,24}$/.test(username)) {
    return res.status(400).json({ error: "昵称需为 2-24 个字母、数字、空格、下划线或短横线。" });
  }
  if (password.length < 4) {
    return res.status(400).json({ error: "密码至少需要 4 个字符。" });
  }
  if (db.prepare("SELECT id FROM users WHERE username = ?").get(username)) {
    return res.status(409).json({ error: "这个昵称已经注册。" });
  }

  const result = db.prepare(
    "INSERT INTO users(username,password,created_at) VALUES(?,?,?)"
  ).run(username, hash(password));

  const user = { id: Number(result.lastInsertRowid), username };
  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, user);
  res.json({ token, username });
});

app.post("/api/login", (req, res) => {
  const username = String(req.body.username || "").trim();
  const password = String(req.body.password || "");
  const user = db.prepare(
    "SELECT id, username FROM users WHERE username = ? AND password = ?"
  ).get(username, hash(password));

  if (!user) return res.status(401).json({ error: "账号或密码错误。" });

  const token = crypto.randomBytes(32).toString("hex");
  sessions.set(token, user);
  res.json({ token, username: user.username });
});

function sendOnline(room) {
  const members = [...online.values()]
    .filter(u => u.room === room)
    .map(u => ({ username: u.username }));
  io.to(room).emit("online", members);
}

function sendHistory(socket, room) {
  const rows = db.prepare(`
    SELECT username, text, created_at AS time
    FROM messages
    WHERE room = ?
    ORDER BY id DESC
    LIMIT 100
  `).all(room).reverse();
  socket.emit("history", rows);
}

io.on("connection", socket => {
  socket.on("auth", token => {
    const user = sessions.get(String(token || ""));
    if (!user) return socket.emit("authError", "登录已失效，请重新登录。");

    online.set(socket.id, { ...user, room: "general" });
    socket.join("general");
    socket.emit("ready", { username: user.username, rooms });
    sendHistory(socket, "general");
    sendOnline("general");
  });

  socket.on("room", requestedRoom => {
    const user = online.get(socket.id);
    if (!user) return;

    const room = validRoom(requestedRoom);
    if (room === user.room) {
      return sendHistory(socket, room);
    }

    const oldRoom = user.room;
    socket.leave(oldRoom);
    sendOnline(oldRoom);

    user.room = room;
    socket.join(room);
    sendHistory(socket, room);
    sendOnline(room);
  });

  socket.on("message", rawText => {
    const user = online.get(socket.id);
    if (!user) return;

    const text = String(rawText || "").trim().slice(0, 1000);
    if (!text) return;

    if (db.prepare("SELECT username FROM bans WHERE username = ?")
        .get(user.username)) {
      return socket.emit("notice", "你已被限制发言。");
    }

    const now = new Date().toISOString();
    const result = db.prepare(`
      INSERT INTO messages(room,user_id,username,text,created_at)
      VALUES(?,?,?,?,?)
    `).run(user.room, user.id, user.username, text, now);

    io.to(user.room).emit("message", {
      id: Number(result.lastInsertRowid),
      username: user.username,
      text,
      time: now
    });
  });

  socket.on("disconnect", () => {
    const user = online.get(socket.id);
    online.delete(socket.id);
    if (user) sendOnline(user.room);
  });
});

const PORT = Number(process.env.PORT || 3000);
server.listen(PORT, () => {
  console.log(`Void Chat 3.0 running at http://localhost:${PORT}`);
});
